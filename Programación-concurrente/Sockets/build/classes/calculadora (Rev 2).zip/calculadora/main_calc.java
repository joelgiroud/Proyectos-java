package calculadora;

public class main_calc {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Calculadora C = new Calculadora();
	}
}
 